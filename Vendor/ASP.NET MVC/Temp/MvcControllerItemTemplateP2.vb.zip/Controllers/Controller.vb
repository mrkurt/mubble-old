﻿Public Class $safeitemname$
    Inherits System.Web.Mvc.Controller

    Sub Index()
        ' Add Action logic here
    End Sub
End Class
