﻿Public Partial Class $safeitemname$
    Inherits System.Web.Mvc.ViewUserControl

End Class
